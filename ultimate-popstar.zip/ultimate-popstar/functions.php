
<?php

add_theme_support( 'title-tag' );

function menu_item_desc( $item_id, $item ) {
	$menu_item_desc = get_post_meta( $item_id, '_menu_item_desc', true );
	?>

	<div style="clear: both;">
	    <span class="description"><?php _e( "Item Icon", 'menu-item-desc' ); ?></span><br />
	    <input type="hidden" class="nav-menu-id" value="<?php echo $item_id ;?>" />
	    <div class="logged-input-holder">
	        <select type="select" name="menu_item_desc[<?php echo $item_id ;?>]" id="menu-item-desc-<?php echo $item_id ;?>" value="<?php echo esc_attr( $menu_item_desc ); ?>" >
          <option value="fb">Facebook</option>
          <option value="tw">Twitter</option>
          <option value="yt">Youtube</option>
          <option value="tk">TikTok</option>
          <option value="sp">Spotify</option>
          </select>
	    </div>
	</div>

	<?php
}
add_action( 'wp_nav_menu_item_custom_fields', 'menu_item_desc', 10, 2 );

function save_menu_item_desc( $menu_id, $menu_item_db_id ) {
	if ( isset( $_POST['menu_item_desc'][$menu_item_db_id]  ) ) {
		$sanitized_data = sanitize_text_field( $_POST['menu_item_desc'][$menu_item_db_id] );
		update_post_meta( $menu_item_db_id, '_menu_item_desc', $sanitized_data );
	} else {
		delete_post_meta( $menu_item_db_id, '_menu_item_desc' );
	}
}
add_action( 'wp_update_nav_menu_item', 'save_menu_item_desc', 10, 2 );

function show_menu_item_desc( $title, $item ) {
	if( is_object( $item ) && isset( $item->ID ) ) {
		$menu_item_desc = get_post_meta( $item->ID, '_menu_item_desc', true );
		if ( ! empty( $menu_item_desc ) ) {

      $lmao = get_bloginfo('template_url');
      $title .= '<img src="' . $lmao . '/Assets/images/' . $menu_item_desc . '.png" alt="' . $menu_item_desc . ' contact link" class="footer-icon">';
		}
	}
	return $title;
}
add_filter( 'nav_menu_item_title', 'show_menu_item_desc', 10, 2 );

function my_theme_setup() {
  add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'my_theme_setup' );

function register_my_menus()
{
  register_nav_menus(
    array(
      'header-menu' => __('Header Menu'),
      'bottom-menu' => __('Bottom Menu'),
      'information-menu' => __('Information Menu'),
    )
  );
}
add_action('init', 'register_my_menus');

function themeslug_sanitize_select( $input, $setting ) {
  $input = sanitize_key( $input );
  $choices = $setting->manager->get_control( $setting->id )->choices;
  return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}

function your_theme_customizer_setting($wp_customize)
{

  $wp_customize->add_setting( 'themeslug_select_setting_id', array(
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'themeslug_sanitize_select',
    'default' => '3',
  ) );
  
  $wp_customize->add_control( 'themeslug_select_setting_id', array(
    'type' => 'select',
    'section' => 'title_tagline', 
    'label' => __( 'Carousel Items' ),
    'description' => __( 'Select the limit of items for display' ),
    'choices' => array(
      '3' => __( '3' ),
      '6' => __( '6' ),
      '9' => __( '9' ),
    ),
  ) );

  $wp_customize->add_panel( 'panel_id', array(
    'priority' => 160,
    'capability' => 'edit_theme_options',
    'theme_supports' => '', 
    'title' => __( 'Título Panel', 'your_textdomain' ),
    'description' => __( 'Descripción Panel', 'your_textdomain' ),
) );

  $wp_customize->add_setting('profile-picture');
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'profile-picture', array(
    'label' => 'Upload the profile picture of the band',
    'section' => 'title_tagline',
    'settings' => 'profile-picture',
    'priority' => 8
  )));

  $wp_customize->add_setting('artist-picture');
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'artist-picture', array(
    'label' => 'Upload the artist picture of the band',
    'section' => 'title_tagline',
    'settings' => 'artist-picture',
    'priority' => 8
  )));

  $wp_customize->add_setting('youtube-url');
  $wp_customize->add_control( 'youtube-url-control', array(
    'label' => __('Youtube URL', 'cvh'),
    'section' => 'title_tagline',
    'settings' => 'youtube-url',
    'type' => 'text',
    'description' => 'Add as follows: https://www.youtube.com/embed/...',
));

$wp_customize->add_setting('credits-text');
$wp_customize->add_control( 'credits-text-control', array(
  'label' => __('Artist Credits', 'cvh'),
  'section' => 'title_tagline',
  'settings' => 'credits-text',
  'type' => 'text',
  'description' => 'Name the credits of the artist',
));

$wp_customize->add_setting('profile-description-text');
$wp_customize->add_control( 'profile-description-control', array(
  'label' => __('Artist Description', 'cvh'),
  'section' => 'title_tagline',
  'settings' => 'profile-description-text',
  'type' => 'textarea',
  'description' => 'Description of the artist',
));

}
add_action('customize_register', 'your_theme_customizer_setting');

function check_home()
{
  if (is_home() || is_front_page()) {
    function defer_parsing_of_javascript($url)
    {
      if (FALSE === strpos($url, '.js')) return $url;
      if (strpos($url, 'jquery.js')) return $url;
      return "$url' defer ";
    }
    add_filter('clean_url', 'defer_parsing_of_javascript', 11, 1);
  }

    function add_css_js()
    {
      wp_enqueue_style('style', get_stylesheet_uri() );

      if (is_page_template( 'news.php' ) || is_category()  ) {
      wp_enqueue_style('page', get_template_directory_uri() . '/Assets/css/page.css');
      }
      else if (is_page_template( 'profile.php' )  ) {
      wp_enqueue_style('page', get_template_directory_uri() . '/Assets/css/page.css');
      wp_enqueue_style('profile', get_template_directory_uri() . '/Assets/css/profile.css');
      }
      else if (is_page_template( 'discography.php' )  ) {
      wp_enqueue_style('page', get_template_directory_uri() . '/Assets/css/page.css');
      wp_enqueue_style('discography', get_template_directory_uri() . '/Assets/css/discography.css');
      }
      else if (is_single() == true || is_page()   ) {
      wp_enqueue_style('page', get_template_directory_uri() . '/Assets/css/page.css');
      wp_enqueue_style('single-page', get_template_directory_uri() . '/Assets/css/single-page.css');
      }
      else if ( is_404()  ) {
      wp_enqueue_style('page', get_template_directory_uri() . '/Assets/css/page.css');
      wp_enqueue_style('single-page', get_template_directory_uri() . '/Assets/css/single-page.css');
      wp_enqueue_style('404', get_template_directory_uri() . '/Assets/css/404.css');
      }
      else{
        wp_enqueue_script('script', get_template_directory_uri() . '/Assets/javascript/script.js', "", "", false);
      }
    }
    add_action('wp_enqueue_scripts', 'add_css_js');
}
add_action('wp', 'check_home');

function remove_admin_login_header() {
  remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_login_header');

?>