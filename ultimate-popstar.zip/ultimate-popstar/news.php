<?php /* Template Name: news */ ?>

<?php get_header() ?>

<section class="news-section-container">
<div style="background-image: url(<?php echo esc_url(get_theme_mod('profile-picture')); ?>);" class="news-image-container"></div>
<div class="news-info-container">
<div class="news-item-container">

<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; ?>

<?php
$category_id = get_cat_ID('release');
$data = new WP_Query(array(
    'post_type' => 'post',
    'category__not_in' => $category_id,
    'posts_per_page' => 7, 
    'paged' => $paged,
));
?>

<?php
if($data->have_posts()) :
while($data->have_posts())  : $data->the_post();
$total_pages = $data->max_num_pages;
?>  

<div class="news-item">
<span class="news-date"> <?php echo get_the_date('d/m/Y'); ?> </span>
<span class="news-type"><?php the_category() ?></span>
<a href=" <?php the_permalink(); ?> ">
<p class="news-content"><?php the_title() ?></p>
</a>
</div>

<?php
endwhile;
?>
</div>

<div class="page-index-container">
<ul>
<?php
if ($total_pages > 1){
    $current_page = max(1, get_query_var('paged'));
    echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '/page/%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'prev_text'    => __('« prev'),
            'next_text'    => __('next »'),
    ));
}
?> 

<?php else :?>
<h3><?php _e('No entries founds', ''); ?></h3>
<?php endif; ?>
<?php wp_reset_postdata();?>
</ul>
</div>

</div>
</section>
<?php get_footer(); ?>