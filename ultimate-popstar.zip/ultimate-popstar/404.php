<?php /* Template Name: 404 */ ?>

<?php get_header() ?>

    <section class="news-section-container error-container">
    <div class="error-header">SORRY, NO PAGE FOUND</div>
    </section>

    <?php get_footer(); ?>