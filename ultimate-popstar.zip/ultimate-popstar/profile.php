<?php /* Template Name: profile */ ?>

<?php get_header() ?>

    <section class="profile-container">

    <div class="profile-item">
            <div style="background-image: url(<?php echo esc_url(get_theme_mod('artist-picture')); ?>);" class="picture-child child-big"></div>
            <div style="background-image: url(<?php echo esc_url(get_theme_mod('artist-picture')); ?>);" class="picture-child child-small"></div>
            <div class="text-child">
                <pre>
<?php echo (get_theme_mod('profile-description-text')); ?>
            </pre>
            </div>
        </div>

    </section>


    <?php get_footer(); ?>
</body>

</html>