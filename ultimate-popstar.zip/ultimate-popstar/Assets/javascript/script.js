const slideItems =  document.querySelectorAll(".carousel-item-wrapper")
const slideArrow = document.querySelectorAll(".slide-item")
let showIndex = (currentIndex) =>{
    removeActive()
    slideItems[currentIndex].classList.add("active")
    }

let removeActive = () =>{
    slideItems.forEach(function(element){
        element.classList.remove("active")
        })
}

currentIndex = 0;
showIndex(currentIndex)

let swipeIndex = (swipeNumber) => {
    currentIndex = currentIndex + swipeNumber
    if(currentIndex > slideItems.length -1){
        currentIndex = 0
    }
    else if(currentIndex < 0){
        currentIndex = slideItems.length - 1
    }
    showIndex(currentIndex)
  }

slideArrow.forEach(function(element){
element.addEventListener("click", function(){ swipeIndex(parseInt(element.dataset.slideValue, 10)) })
})

