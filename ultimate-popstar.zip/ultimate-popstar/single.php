<?php /* Template Name: single */ ?>

<?php get_header() ?>

    <section class="news-section-container">
        <div class="news-image-container"></div>
        <div class="news-text-container">
            <div class="news-item">
            <span class="news-date"> <?php echo get_the_date('d/m/Y'); ?> </span>
            <span class="news-type"><?php the_category() ?></span>
            <a href=" <?php the_permalink(); ?> ">
            <p class="news-content"><?php the_title() ?></p>
            </a>
            </div>
            <div class="news-item-content">
                <?php the_content()?>
            </div>
        </div>

    </section>

    <?php get_footer(); ?>