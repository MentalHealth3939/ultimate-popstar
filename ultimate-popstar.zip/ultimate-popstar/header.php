<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100;300;400;500;600;700;800&family=Nixie+One&display=swap" rel="stylesheet">
    <?php wp_head() ?>

</head>

<body class="single-body" >

    <header>
        <div class="header-container main-container">
            <div class="logo header-logo"><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name') ?></a></div>
            <div class="main-nav">

            <?php
            wp_nav_menu(array(
                'theme_location' => 'header-menu',
                'container' => 'nav',
                'container_class' => 'header-nav'
            ));
            ?>
            </div>
        </div>
    </header>