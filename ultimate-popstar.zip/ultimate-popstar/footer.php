<footer class="main-footer">
        <div class="footer-main-wrapper main-container">
            <div class="footer-item footer-logo-container">
                <div class="logo footer-logo" ><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name') ?></a></div>
                <div class="footer-band-info">Designed by <span>yolocobi crafts</span></div>
            </div>


            <div class="footer-item  footer-nav">
                <nav class="footer-nav">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'information-menu',
                'container' => 'nav',
                'container_class' => 'information-nav'
            ));
            ?>

                </nav>
            </div>
        </div>
        <div class="footer-contact">
            <div class="contact-item contact-us">Contact Us</div>
            <div class="contact-item icon-container">

            <?php
            wp_nav_menu(array(
                'theme_location' => 'bottom-menu',
                'container' => 'nav',
                'container_class' => 'bottom-nav'
            ));
            ?>

            </div>
            <div class="contact-item credits">Copyright © <?php echo (get_theme_mod('credits-text'));?> All Rights Reserved.
            </div>
        </div>
    </footer>

</body>

</html>