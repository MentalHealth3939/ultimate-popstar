<?php get_header() ?>

    <section class="band-picture">
        <div style="background-image: url(<?php echo esc_url(get_theme_mod('profile-picture')); ?>);" class="band-container main-container">
        </div>
    </section>
    <section class="news-carousel">
        <div data-slide-value="-1" class="slide-item slide-left-icon">&lt;</div>

<!-- LOOP -->
<div class="main-container slideshow-container">

<?php $post_number = 1; ?>
<?php $post_number2 = 1; ?>

<?php 

$category_id = get_cat_ID('release');
query_posts('cat=-'. $category_id. '');
if (have_posts()) :
while (have_posts()) : the_post();
?>

<?php if($post_number > 3){ $post_number = 1;  } ?>

<?php if($post_number2 <= intval((get_theme_mod('themeslug_select_setting_id'))) ){ ?>

<?php if($post_number == 1){  ?> <div class="carousel-item-wrapper"> <?php }?>

<div class="carousel-item-content">
<div style="background-image: url(<?php echo get_the_post_thumbnail_url() ?>)" class="carousel-image"></div>
<a class="carouse-item-content-text" href=" <?php the_permalink(); ?> ">
<div><?php the_title() ?></div>
</a>
</div>

<?php $total = count($posts); ?>
<?php if($post_number2 + 1 /* + 1 */ == $total || $post_number == 3 || $post_number2 /* + 1 */ == intval((get_theme_mod('themeslug_select_setting_id')))){  ?> </div> <?php }?>

<?php }?>

<?php $post_number++; ?>
<?php $post_number2++; ?>

<?php
endwhile;
endif;
wp_reset_postdata();
?>

</div>
<!-- LOOP -->
    <div data-slide-value="1" class="slide-item slide-right-icon">&gt;</div>
    </section>

    <section class="news-corner">

        <div class="main-container">
            <div class="box-item news-box">
                <h1 class="news-box-header">NEWS</h1>
                <div class="news-container">

                <?php
                    $category_id = get_cat_ID('release');
                    query_posts( array(
                        'category__not_in' => $category_id,
                        'posts_per_page' => -1
                    ) );
                    $post_number = 0;
                    if ( have_posts() ) : 
                        while (have_posts()) : the_post();
                    ?>
                            <div class="news-item">
                                <span class="news-date"> <?php echo get_the_date('d/m/Y'); ?> </span>
                                <span class="news-type"><?php the_category() ?></span>
                                <a href=" <?php the_permalink(); ?> ">
                                <p class="news-content"><?php the_title() ?></p>
                                </a>
                            </div>

                    <?php  
                    $post_number++;
                    if($post_number == 20 ){ break; } 
                    ?>

                    <?php
                    endwhile;
                    endif;
                    ?>

                </div>
            </div>
            <div class="box-item movie-box">
                <h1 class="movie-box-header">VIDEO</h1>
                <div class="movie-container">
                    <iframe class="movie-container-item" src=" <?php echo (get_theme_mod('youtube-url')); ?>"  >
                    </iframe>
                </div>
            </div>
        </div>

    </section>

    <?php get_footer(); ?>
