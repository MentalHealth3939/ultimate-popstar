<?php /* Template Name: category */ ?>

<?php get_header() ?>
<section class="news-section-container">
        <div style="background-image: url(<?php echo esc_url(get_theme_mod('profile-picture')); ?>);" class="news-image-container"></div>

        <div class="news-info-container">

            <div class="news-item-container">
<?php
if ( have_posts() ) : 
    while ( have_posts() ) : the_post();
        ?>

<div class="news-item">
<span class="news-date"> <?php echo get_the_date('d/m/Y'); ?> </span>
<span class="news-type"><?php the_category() ?></span>
<a href=" <?php the_permalink(); ?> ">
<p class="news-content"><?php the_title() ?></p>
</a>
</div>

        <?php
    endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'textdomain' );
endif;
?>

</div>
</div>
</section>
<?php get_footer(); ?>