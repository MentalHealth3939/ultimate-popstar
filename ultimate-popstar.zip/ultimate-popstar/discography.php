<?php /* Template Name: discography */ ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dream Polaris | DISCOGRAPHY</title>

    <link
    href="https://fonts.googleapis.com/css2?family=Lexend:wght@100;300;400;500;600;700;800&family=Nixie+One&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="news.css">
    <link rel="stylesheet" href="discography.css">
    <?php wp_head() ?>
</head>

<body class="single-body">

<?php get_header() ?>

<section class="news-section-container">
<div class="news-info-container">

<div class="disco-items-container">

<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; ?>

<?php
$data = new WP_Query(array(
    'post_type' => 'post',
    'category_name'  => 'release',
    'posts_per_page' => 12,
    'paged' => $paged,
));
?>

<?php
if($data->have_posts()) :
while($data->have_posts())  : $data->the_post();
$total_pages = $data->max_num_pages;
?>  

<a href="<?php the_permalink(); ?>">
<div class="disco-item">
<div style="background-image: url(<?php echo get_the_post_thumbnail_url() ?>)" class="cover-image"></div>
<div class="release-title"><?php the_title() ?></div>
<span class="release-type">
<?php
$tags = get_the_tags();
if ($tags) {
foreach( $tags as $tag ) {
echo $tag->name;
}
}
?>
</span>
</div>
</a>

<?php
endwhile;
?>
</div>

<div class="page-index-container">
<ul>
<?php
if ($total_pages > 1){
    $current_page = max(1, get_query_var('paged'));
    echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '/page/%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'prev_text'    => __('« prev'),
            'next_text'    => __('next »'),
    ));
}
?> 

<?php else :?>
<h3><?php _e('No entries founds', ''); ?></h3>
<?php endif; ?>
<?php wp_reset_postdata();?>
</ul>
</div>
</div>
</div>
</section>

<?php get_footer(); ?>
</body>

</html>